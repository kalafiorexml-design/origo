
# ORIGO Trust Pack (OPAH-1)

This pack contains:
- trust/blocks/*.json — example chain: GENESIS → OMEGA_ADD → DOC_ANCHOR
- trust/scripts/verify_origo_chain.py — verifier (hash/link; optional Ed25519 signature check if PyNaCl present)
- trust/schema/block.schema.json — minimal JSON schema
- trust/keys/public/README.md — where to put public keys (base64 Ed25519)

Quick start
-----------
1) Edit placeholders in blocks:
   - Replace ALFA/OMEGA* placeholders with real base64 Ed25519 public keys.
   - (Optional) Put document SHA-256 into 002_doc_anchor.json.

2) Compute signatures:
   - Sign the *blockhash* (hex string) of each block using your private keys, produce base64 signature bytes, and replace BASE64_SIG_REPLACE_ME.

3) Verify:
   python trust/scripts/verify_origo_chain.py trust/blocks --allow-unsigned

Generated: 2025-08-30T22:21:00Z
