# ORIGO / OPAH-1 Public Keys

Wklej klucze publiczne w formacie base64 (Ed25519). Przykład:
- ALFA_PUBKEY_PLACEHOLDER
- OMEGA0_PUBKEY_PLACEHOLDER
- OMEGA1_PUBKEY_PLACEHOLDER

Prywatne klucze trzymaj poza repozytorium.
