#!/usr/bin/env python3
# verify_origo_chain.py — OPAH-1 chain verifier
import sys, os, json, hashlib, argparse

def canon(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")

def calc_blockhash(block):
    hobj = {k: v for k, v in block.items() if k not in ("signatures", "blockhash")}
    return hashlib.sha256(canon(hobj)).hexdigest()

def load_blocks(path):
    files = [f for f in os.listdir(path) if f.endswith(".json")]
    files.sort()
    blocks = []
    for fn in files:
        full = os.path.join(path, fn)
        with open(full, "r", encoding="utf-8") as fh:
            blk = json.load(fh)
        blocks.append((fn, blk))
    return blocks

def try_verify_signatures(block, allow_unsigned=False):
    try:
        import nacl.signing, nacl.exceptions, base64
    except Exception as e:
        unsigned = any(sig.get("sig","").startswith("BASE64_SIG_REPLACE_ME") for sig in block.get("signatures",[]))
        if unsigned and not allow_unsigned:
            return False, "No signature lib; and signatures are placeholders. Use --allow-unsigned to skip."
        return True, "Signature check skipped (PyNaCl not installed)."
    import base64
    msg = calc_blockhash(block).encode("utf-8")
    for sig in block.get("signatures", []):
        sig_b64 = sig.get("sig","")
        if sig_b64.startswith("BASE64_SIG_REPLACE_ME"):
            if allow_unsigned:
                continue
            return False, "Placeholder signature present. Provide real signatures or use --allow-unsigned."
        try:
            pub_b64 = sig.get("pubkey","")
            verify_key = nacl.signing.VerifyKey(base64.b64decode(pub_b64))
            verify_key.verify(msg, base64.b64decode(sig_b64))
        except Exception as e:
            return False, f"Signature verify failed: {e}"
    return True, "Signatures OK."

def main():
    ap = argparse.ArgumentParser(description="Verify OPAH-1 ORIGO chain")
    ap.add_argument("blocks_dir", help="Path to blocks directory")
    ap.add_argument("--allow-unsigned", action="store_true", help="Allow placeholder signatures")
    args = ap.parse_args()

    pairs = load_blocks(args.blocks_dir)
    if not pairs:
        print("No blocks found."); sys.exit(2)

    prev_hash = None; ok_all = True
    for i, (fn, blk) in enumerate(pairs):
        print(f"== {fn} ==")
        h = calc_blockhash(blk); bh = blk.get("blockhash")
        if h != bh:
            print(f"  [FAIL] blockhash mismatch\n   expected: {bh}\n   computed: {h}"); ok_all = False
        else:
            print(f"  [OK] blockhash matches: {bh[:16]}…")
        pv = blk.get("prev")
        if i == 0:
            if pv is not None:
                print("  [FAIL] genesis.prev must be null"); ok_all = False
            else:
                print("  [OK] genesis prev=null")
        else:
            if pv != prev_hash:
                print(f"  [FAIL] prev mismatch\n   expected prev: {prev_hash}\n   found prev:    {pv}"); ok_all = False
            else:
                print(f"  [OK] prev links: {pv[:16]}…")
        s_ok, s_msg = try_verify_signatures(blk, allow_unsigned=args.allow_unsigned)
        print(f"  [SIG] {s_msg}")
        prev_hash = bh
    print("\n" + ("CHAIN OK ✅" if ok_all else "CHAIN INVALID ❌"))
    sys.exit(0 if ok_all else 1)

if __name__ == "__main__":
    main()
